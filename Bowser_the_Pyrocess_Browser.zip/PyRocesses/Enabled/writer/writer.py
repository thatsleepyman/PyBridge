def writer(message):
    print(message)
    return